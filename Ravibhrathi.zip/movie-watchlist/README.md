# 🎬 Movie Watchlist App (Tailwind)
Features:
- Add to watchlist
- Mark as watched
- Remove
- Persists with localStorage
- Styled with Tailwind CSS

## 🚀 Run locally
```bash
npm install
npm run dev
```
